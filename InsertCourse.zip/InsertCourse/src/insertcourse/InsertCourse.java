
package insertcourse;

import java.sql.*;
import java.util.Scanner;


public class InsertCourse {

    public static void main(String[] args) {
      //prompt for course name, course number, course description, course units.
      final String DATABASE_URL = "jdbc:derby://localhost:1527/School";
      final String QUERY = "INSERT INTO DEMO18B.COURSE (COURSENUMBER, COURSENAME, COURSEDESCRIPTION, COURSEUNITS) VALUE (?,?,?,?)";
      
        System.out.print("Enter Course Number: ");
        String courseNumber = new Scanner(System.in).nextLine();
        
        System.out.print("Enter Course Name: ");
        String courseName = new Scanner(System.in).nextLine();
        
        System.out.print("Enter Course Description: ");
        String courseDescription = new Scanner(System.in).nextLine();
        
        System.out.print("Enter Course Units: ");
        float courseUnits = new Scanner(System.in).nextFloat();
        
        //**prevents an SQL injection attack! VERY IMPORTANT!
        //if anything goes wrong, it will happen here.
         try
        {
            Connection conn = DriverManager.getConnection(
                DATABASE_URL, "demo18b", "Password"); //Username then Password.
            
            PreparedStatement insertNewCourse = conn.prepareStatement(QUERY);
            insertNewCourse.setString(1,courseNumber);
            insertNewCourse.setString(2,courseName);
            insertNewCourse.setString(3,courseDescription);
            insertNewCourse.setFloat(4,courseUnits);
            
            insertNewCourse.executeUpdate();
        }
        catch(Exception e)
        {
            System.err.println(e.getMessage());
        }
    }
    
}
